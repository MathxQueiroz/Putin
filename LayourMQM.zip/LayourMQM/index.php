<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Layout</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <div id="header">
    <div class="div_jingle">
            <img class="img_top" src="./images/carregando.gif">
            <h1>A Procura de Cogumelos</h1>
            <img class="img_top2" src="./images/carregando.gif">
        </div>
    </div>
    <div div="Main">
        <div>
            <h2>Race With End</h2>
        </div>
<div class="div_actions">
    <div class="card_actions">
        <h3>Mario</h3>
        <img class="img_card" src="./images/Mario2.png">
    </div>
    <div class="card_actions">
        <h3>Luigi</h3>
        <img class="img_card" src="./images/Luigi.png">
    </div>
    <div class="card_actions">
        <h3>Peach</h3>
        <img class="img_card" src="./images/Peach.png">
    </div>
    <div class="card_actions">
        <h3>Yoshi</h3>
        <img class="img_card" src="./images/Yoshi.png">
    </div>
</div>
<div id="c">

</div>

</div>
</body>
</html>